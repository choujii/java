package todo.model;

public class Category {
    public int id;
    public String name;

    public String toString() {
        return name;
    }
}
